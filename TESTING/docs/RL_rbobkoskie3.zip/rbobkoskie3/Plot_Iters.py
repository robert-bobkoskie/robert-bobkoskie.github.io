import pydotplus
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

def Make_Plot(gridworld_shape, iter_idx, num_iters_p, run_time_p,
              num_iters_v, run_time_v, run_time_Q, name):

    #########################
    # num iters
    #########################
    plt.figure(figsize=(20, 7))

    plt.subplot(121)
    plt.title(str(name)+' Num Iterations: Policy', fontsize=28)
    plt.plot(iter_idx, num_iters_p)
    plt.xlabel("Gridworld"+str(" ".join(str(x) for x in gridworld_shape)),
               fontsize=20)
    plt.ylabel("Num Iterations", fontsize=20)
    #plt.yscale('log')
    #plt.yscale('linear')

    plt.subplot(122)
    plt.title(str(name)+' Num Iterations: Value', fontsize=28)
    plt.plot(iter_idx, num_iters_v)
    plt.xlabel("Gridworld"+str(" ".join(str(x) for x in gridworld_shape)),
               fontsize=20)
    plt.ylabel("Num Iterations", fontsize=20)
    #plt.legend(['RHC', 'SA', 'GA', 'MIMIC'], loc='upper left')
    #plt.yscale('log')
    #plt.yscale('linear')

    plt.subplots_adjust(wspace=0.25)
    #plt.show()
    plt.savefig('ITERS_'+str(name)+".png")
    plt.close()

    #########################
    # run time
    #########################
    plt.figure(figsize=(20, 7))

    plt.subplot(131)
    plt.title(str(name)+' Run Time: Policy', fontsize=28)
    plt.plot(iter_idx, run_time_p)
    plt.xlabel("Gridworld"+str(" ".join(str(x) for x in gridworld_shape)),
               fontsize=16)
    plt.ylabel("Run Time (sec)", fontsize=20)
    #plt.yscale('log')
    #plt.yscale('linear')

    plt.subplot(132)
    plt.title(str(name)+' Run Time: Value', fontsize=28)
    plt.plot(iter_idx, run_time_v)
    plt.xlabel("Gridworld"+str(" ".join(str(x) for x in gridworld_shape)),
               fontsize=16)
    plt.ylabel("Run Time (sec)", fontsize=20)
    #plt.legend(['RHC', 'SA', 'GA', 'MIMIC'], loc='upper left')
    #plt.yscale('log')
    #plt.yscale('linear')

    plt.subplot(133)
    plt.title(str(name)+' Run Time: Q-Learn', fontsize=28)
    plt.plot(iter_idx, run_time_Q)
    plt.xlabel("Gridworld"+str(" ".join(str(x) for x in gridworld_shape)),
               fontsize=16)
    plt.ylabel("Run Time (sec)", fontsize=20)
    #plt.legend(['RHC', 'SA', 'GA', 'MIMIC'], loc='upper left')
    #plt.yscale('log')
    #plt.yscale('linear')

    plt.subplots_adjust(wspace=0.25)
    #plt.show()
    plt.savefig('TIME_'+str(name)+".png")
    plt.close()
