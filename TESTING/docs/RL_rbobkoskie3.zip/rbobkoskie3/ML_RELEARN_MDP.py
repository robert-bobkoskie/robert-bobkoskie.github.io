
import numpy as np
import sys, time, timeit, math
import Plot_Iters

def Py_Brain():
    ############################
    # pybrain
    ############################
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    import itertools
    from scipy import linalg

    from pybrain.rl.environments.mazes import Maze, MDPMazeTask
    from pybrain.rl.learners.valuebased import ActionValueTable
    from pybrain.rl.agents import LearningAgent
    from pybrain.rl.learners import Q, SARSA
    from pybrain.rl.experiments import Experiment
    from pybrain.rl.environments import Task

    import pylab
    #pylab.gray()
    #pylab.ion()

    '''
    structure = np.array([[1, 1, 1, 1, 1, 1, 1, 1, 1],
                          [1, 0, 0, 1, 0, 0, 0, 0, 1],
                          [1, 0, 0, 1, 0, 0, 1, 0, 1],
                          [1, 0, 0, 1, 0, 0, 1, 0, 1],
                          [1, 0, 0, 1, 0, 1, 1, 0, 1],
                          [1, 0, 0, 0, 0, 0, 1, 0, 1],
                          [1, 1, 1, 1, 1, 1, 1, 0, 1],
                          [1, 0, 0, 0, 0, 0, 0, 0, 1],
                          [1, 1, 1, 1, 1, 1, 1, 1, 1]])
    '''
    structure = np.array([[1, 1, 1, 1, 1],
                          [1, 1, 0, 0, 1],
                          [1, 1, 0, 1, 1],
                          [1, 0, 0, 1, 1],
                          [1, 1, 1, 1, 1]])

    num_states = int(structure.shape[0]*structure.shape[1])
    SQRT = int(math.sqrt(num_states))
    #print structure.item((1, 3))
    #environment = Maze(structure, (7, 7)) #second parameter is goal field tuple
    environment = Maze(structure, (1, 3)) #second parameter is goal field tuple
    print type(environment)
    print environment
    # Standard maze environment comes with the following 4 actions:
    # North, South, East, West
    controller = ActionValueTable(num_states, 4) #[N, S, E, W] 
    controller.initialize(1)

    learner = Q()
    agent = LearningAgent(controller, learner)
    np.not_equal(agent.lastobs, None)
    task = MDPMazeTask(environment)
    experiment = Experiment(task, agent)

    #while True:
    for x in range(4):
        print x
        experiment.doInteractions(10)
        agent.learn()
        agent.reset()

        pylab.pcolor(controller.params.reshape(num_states,4).max(1).reshape(SQRT,SQRT))
        pylab.draw()
        #pylab.show()
        name='MAZE'
        plt.savefig(str(name)+'_PLOT.png')
    plt.close()


def Check_Grid_Idx(grid, idx):
    is_valid = True

    try:
        grid[idx]
        if idx[0] < 0 or idx[1] < 0:
            is_valid = False
            #print '1 here', idx, grid[idx]
        elif np.isnan(grid[idx]):
            is_valid = False
        else:
            is_valid = True
            #print 'TRUE'
    except:
        is_valid = False
        #print '2 here', idx, grid[idx]

    return is_valid

def Mdp_Tool_Box(A, prob_A, gridworld, term_state, num_states, gamma, epsilon, two_d):
    DEBUG_RESULTS = False
    DEBUG_ITERS = False
    DEBUG_L1 = False
    DEBUG_L2 = False

    #############################
    # mdptoolbox
    #############################
    import mdptoolbox
    import mdptoolbox.example

    prob_A_stoc = (1 - prob_A) / int(len(A)-1) #There will be (prob_A - 1) choices of equal prob
    prob_move = 1.0 / int(len(A))
    num_actions = int(len(A))

    # Construct Markov matrix of transition probabilities: P(A,S,S)
    # Construct rewards matrix: R (S,A)
    MDP_P = np.zeros( (num_actions, num_states, num_states) )
    MDP_R = np.zeros( (num_states, num_actions) )

    prob_sum = {}

    for idx, val in np.ndenumerate(gridworld):
        start_state = idx
        start_val = val
        if two_d:
            STATE = (gridworld.shape[1]*start_state[0])+start_state[1]

            idx_N = (idx[0]-1, idx[1])   #NORTH
            idx_S = (idx[0]+1, idx[1])   #SOUTH
            idx_E = (idx[0],   idx[1]+1) #EAST
            idx_W = (idx[0],   idx[1]-1) #WEST
            action_idx = {'N':idx_N, 'S':idx_S, 'E':idx_E, 'W':idx_W,}

        else:
            STATE = ((gridworld.shape[2]*start_state[1]) + start_state[2] + start_state[0]) +\
                    ((gridworld.shape[1]*gridworld.shape[2]*start_state[0]) - start_state[0])

            idx_N = (idx[0], idx[1]-1, idx[2])   #NORTH
            idx_S = (idx[0], idx[1]+1, idx[2])   #SOUTH
            idx_E = (idx[0], idx[1],   idx[2]+1) #EAST
            idx_W = (idx[0], idx[1],   idx[2]-1) #WEST

            idx_Z1 = (idx[0]+1, idx[1],   idx[2]) #Z1
            idx_Z2 = (idx[0]-1, idx[1],   idx[2]) #Z2
            action_idx = {'N':idx_N, 'S':idx_S, 'E':idx_E, 'W':idx_W, 'Z1':idx_Z1, 'Z2':idx_Z2}
            

        if DEBUG_L1 == True:
            print '\n-START', start_state, start_val, STATE


        for action in action_idx.keys():
            # Game starts in a terminal state
            if start_state in term_state or np.isnan(start_val):
                MDP_P[ A[action], STATE, STATE ] = 1.0
                if DEBUG_L2 == True:
                    print '  -TERMIONAL', start_state, '--', A[action], STATE
                continue

            is_valid = Check_Grid_Idx(gridworld, action_idx[action])
            if is_valid:
                if two_d:
                    NEXT_STATE = (gridworld.shape[1]*action_idx[action][0])+action_idx[action][1]
                else:
                    NEXT_STATE = ((gridworld.shape[2]*action_idx[action][1]) + action_idx[action][2] + action_idx[action][0]) +\
                                 ((gridworld.shape[1]*gridworld.shape[2]*action_idx[action][0]) - action_idx[action][0])

                MDP_P[ A[action], STATE, NEXT_STATE ] = prob_A
                MDP_R[ STATE, A[action] ] = gridworld[ action_idx[action] ]
                if DEBUG_L1 == True:
                    print '  --------MOVE:', action, action_idx[action], is_valid, gridworld[action_idx[action]],\
                          '--', A[action], STATE, NEXT_STATE
                key = ( A[action], STATE, STATE )
                if key not in prob_sum:
                    prob_sum[ key ] = prob_A
                    if DEBUG_L2 == True:
                        print '             ---INIT MOV:', key, prob_sum[ key ]
                else:
                    prob_sum[ key ] = prob_A + prob_sum[ key ]
                    if DEBUG_L2 == True:
                        print '             ----ADD MOV:', key, prob_sum[ key ]

                for stoc_action in action_idx.keys():
                    if stoc_action != action:
                        MDP_P[ A[stoc_action], STATE, NEXT_STATE ] = prob_A_stoc
                        MDP_R[ NEXT_STATE, A[action] ] = gridworld[ action_idx[action] ]
                        if DEBUG_L1 == True:
                            print '    -STOC MOVE:', stoc_action, '--',\
                                  A[stoc_action], STATE, NEXT_STATE
                        key = ( A[stoc_action], STATE, STATE )
                        if key not in prob_sum:
                            prob_sum[ key ] = prob_A_stoc
                            if DEBUG_L2 == True:
                                print '             ---INIT STC:', key, prob_sum[ key ]
                        else:
                            prob_sum[ key ] += prob_A_stoc
                            if DEBUG_L2 == True:
                                print '             ----ADD STC:', key, prob_sum[ key ]

    #print 'SUM OF PROB', prob_sum
    for k, v in prob_sum.items():
        #print k
        MDP_P[ k ] = 1 - v
    
    #print MDP_P
    #print MDP_R
    P = MDP_P
    R = MDP_R

    #P, R = mdptoolbox.example.forest(S=5, r1=4, r2=2)
    #P, R = mdptoolbox.example.rand(10, 3)
    #P, R = mdptoolbox.example.rand(1000, 4, is_sparse=False, mask=None)

    # Policy iteration
    pi = mdptoolbox.mdp.PolicyIteration(P, R, gamma)
    if DEBUG_ITERS == True:
        pi.setVerbose()
    start = timeit.default_timer()
    pi.run()
    stop = timeit.default_timer()
    policy_rt = stop - start

    # Value iteration
    vi = mdptoolbox.mdp.ValueIteration(P, R, gamma, epsilon)
    if DEBUG_ITERS == True:
        vi.setVerbose()
    start = timeit.default_timer()
    vi.run()
    stop = timeit.default_timer()
    value_rt = stop - start

    # Q-learning iteration
    qi = mdptoolbox.mdp.QLearning(P, R, gamma)
    if DEBUG_ITERS == True:
        pass
    qi.setVerbose()
    start = timeit.default_timer()
    qi.run()
    stop = timeit.default_timer()
    Q_rt = stop - start

    if DEBUG_RESULTS == True:
        print '\n==================='
        print 'POLICY', pi.policy
        print pi.iter
        print pi.V

        print '\n==================='
        #print 'POLICY',  vi.policy
        print vi.iter
        print vi.V

        print '\n==================='
        print 'POLICY', qi.policy
        print qi.V
        print qi.Q

        print '\n==================='
        print 'P (A,S,S)', P.shape, 'R (S,A)', R.shape
        print P
        print R

    return pi.policy, pi.iter, policy_rt,\
           vi.V, vi.iter, value_rt,\
           qi.policy, qi.V, qi.Q, Q_rt


def Make_Gridworld(shape, living_util, two_d):
    term_state = []

    if two_d:
        gridworld = np.full((shape[0], shape[1]), -0.01)

        #gridworld[0,                    0]                      = -10.0
        #term_state.append( (0,0) )

        #gridworld[0,                    gridworld.shape[1]-1]   =  10.0
        #term_state.append( (0, int(gridworld.shape[1]-1)) )

        gridworld[gridworld.shape[1]/2-1, gridworld.shape[1]/2+1]   = 10
        term_state.append( (int(gridworld.shape[1]/2-1), int(gridworld.shape[1]/2+1)) )

        gridworld[gridworld.shape[1]/2, gridworld.shape[1]/2+1]     = -10
        term_state.append( (int(gridworld.shape[1]/2), int(gridworld.shape[1]/2+1)) )

        gridworld[gridworld.shape[0]/2-1 : gridworld.shape[0]/2+1,\
                  gridworld.shape[1]/2-1 : gridworld.shape[1]/2+1]  = np.NaN

        num_states = int(gridworld.shape[0] * gridworld.shape[1])

    if not two_d:
        gridworld = np.full((2, shape[0], shape[1]), -0.01)

        for i in range(int(gridworld.shape[0])):
            if i == 0:
                val_1 = -10
                val_2 =  10
            else:
                val_1 =  10
                val_2 = -10

            #gridworld[i,0,0]                                         = val_1
            #term_state.append( (i,0,0) )

            #gridworld[i, 0, gridworld.shape[2]-1]                    = val_2
            #term_state.append( (i, 0, int(gridworld.shape[2]-1)) )

            gridworld[i, gridworld.shape[1]/2-1, gridworld.shape[1]/2+1]  = val_2
            term_state.append( (i, int(gridworld.shape[1]/2-1), int(gridworld.shape[1]/2+1)) )

            gridworld[i, gridworld.shape[1]/2, gridworld.shape[1]/2+1]    = val_1
            term_state.append( (i, int(gridworld.shape[1]/2), int(gridworld.shape[1]/2+1)) )

            gridworld[i, gridworld.shape[1]/2-1 : gridworld.shape[1]/2+1,
                         gridworld.shape[2]/2-1 : gridworld.shape[2]/2+1] = np.NaN

        num_states = int(gridworld.shape[0] * gridworld.shape[1] * gridworld.shape[2])

    return gridworld, num_states, term_state


#############################
def main():
    #Py_Brain()

    two_d = True  #2 dimensional gridworld
    gridworld_shape = []
    prob_A = 0.82
    living_util = 0.01
    gamma = 0.2
    epsilon = 0.01

    policies = []
    num_iters_p = []
    run_time_p = []

    values = []
    num_iters_v = []
    run_time_v = []

    Q_policies = []
    run_time_Q = []

    #############################
    # 2 dimensional gridworld
    if two_d:
    #############################
        name = '2D'
        print '----', name
        A = {'N':0, 'S':1, 'E':2, 'W':3}
        gridw_shape = (2, 2)   #start with this gridworld.shape

        #for i in range(3):  #For testing
        for i in range(4):
            gridw_shape =  2*gridw_shape[0], 2*gridw_shape[1]
            gridworld, num_states, term_state = Make_Gridworld(gridw_shape, living_util, two_d)
            #print gridworld

            policy, p_iter, policy_rt,\
            value, v_iter, value_rt,\
            Q_policy, Q_value, Q_learn, Q_rt = Mdp_Tool_Box(A, prob_A, gridworld, term_state, num_states, gamma, epsilon, two_d)
            policies.append(policy)
            num_iters_p.append(p_iter)
            run_time_p.append(policy_rt)

            values.append(value)
            num_iters_v.append(v_iter)
            run_time_v.append(value_rt)

            Q_policies.append(Q_policy)
            run_time_Q.append(Q_rt)
            gridworld_shape.append(gridw_shape)

        print 'POLICY\n', policies[0]
        print 'VALUES\n', values[0]
        print 'Q-POLICY\n', Q_policies[0]
        iter_idx = [x+1 for x in range(len(num_iters_p))]
        Plot_Iters.Make_Plot(gridworld_shape, iter_idx, num_iters_p, run_time_p,
                             num_iters_v, run_time_v, run_time_Q, name)

    #############################
    # 3 dimensional gridworld
    if not two_d:
    #############################
        name = '3D'
        print '----', name
        A = {'N':0, 'S':1, 'E':2, 'W':3, 'Z1':4, 'Z2':5}
        gridw_shape = (2, 2, 2)   #start with this gridworld.shape

        #for i in range(3):  #For testing
        for i in range(3):
            gridw_shape =  2*gridw_shape[0], 2*gridw_shape[1], 2*gridw_shape[2]
            gridworld, num_states, term_state = Make_Gridworld(gridw_shape, living_util, two_d)
            #print gridworld

            policy, p_iter, policy_rt,\
            value, v_iter, value_rt,\
            Q_policy, Q_value, Q_learn, Q_rt = Mdp_Tool_Box(A, prob_A, gridworld, term_state, num_states, gamma, epsilon, two_d)
            policies.append(policy)
            num_iters_p.append(p_iter)
            run_time_p.append(policy_rt)

            values.append(value)
            num_iters_v.append(v_iter)
            run_time_v.append(value_rt)

            Q_policies.append(Q_policy)
            run_time_Q.append(Q_rt)
            gridworld_shape.append(gridw_shape)

        print 'POLICY\n', policies[0]
        print 'VALUES\n', values[0]
        print 'Q-POLICY\n', Q_policies[0]
        iter_idx = [x+1 for x in range(len(num_iters_p))]
        Plot_Iters.Make_Plot(gridworld_shape, iter_idx, num_iters_p, run_time_p,
                             num_iters_v, run_time_v, run_time_Q, name)


if __name__ == '__main__':
    main()
#############################
