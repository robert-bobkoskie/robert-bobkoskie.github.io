# Your Agent for solving Raven's Progressive Matrices. You MUST modify this file.
#
# You may also create and submit new files in addition to modifying this file.
#
# Make sure your file retains methods with the signatures:
# def __init__(self)
# def Solve(self,problem)
#
# These methods will be necessary for the project's main method to run.

# Install Pillow and uncomment this line to access image processing.
#from PIL import Image

import re, math, operator
from PIL import Image, ImageChops, ImageFilter
import numpy as np

class Agent:
    # The default constructor for your Agent. Make sure to execute any
    # processing necessary before your Agent starts solving problems here.
    #
    # Do not add any variables to this signature; they will not be used by
    # main().
    def __init__(self):
        pass

    # The primary method for solving incoming Raven's Progressive Matrices.
    # For each problem, your Agent's Solve() method will be called. At the
    # conclusion of Solve(), your Agent should return a list representing its
    # confidence on each of the answers to the question: for example 
    # [.1,.1,.1,.1,.5,.1] for 6 answer problems or [.3,.2,.1,.1,0,0,.2,.1] for 8 answer problems.
    #
    # In addition to returning your answer at the end of the method, your Agent
    # may also call problem.checkAnswer(int givenAnswer). The parameter
    # passed to checkAnswer should be your Agent's current guess for the
    # problem; checkAnswer will return the correct answer to the problem. This
    # allows your Agent to check its answer. Note, however, that after your
    # agent has called checkAnswer, it will *not* be able to change its answer.
    # checkAnswer is used to allow your Agent to learn from its incorrect
    # answers; however, your Agent cannot change the answer to a question it
    # has already answered.
    #
    # If your Agent calls checkAnswer during execution of Solve, the answer it
    # returns will be ignored; otherwise, the answer returned at the end of
    # Solve will be taken as your Agent's answer to this problem.
    #
    # Make sure to return your answer *as an integer* at the end of Solve().
    # Returning your answer as a string may cause your program to crash.
    
    debugL1 = True
    debugL2 = False
    debugL3 = False
    debugNP = False
    debugCS = False
    debugCP = False

    def Solve(self,problem):

        print '\n------------------'
        print problem.name, problem.problemType
        print '------------------\n'

        all_scores2x2 = {}
        all_scores3x3 = {}
        figures = {}

        #########################################
        validCompRow2x2 = (['AB',
                            'C1', 'C2', 'C3', 'C4', 'C5', 'C6'])

        validCompCol2x2 = (['AC',
                            'B1', 'B2', 'B3', 'B4', 'B5', 'B6'])

        validCompDiag2x2 = (['BC',
                            'A1', 'A2', 'A3', 'A4', 'A5', 'A6'])

        validCompAll2x2 = validCompRow2x2 + validCompCol2x2 + validCompDiag2x2
        #########################################

        #########################################
        validCompRow3x3 = (['ABC', 'DEF',
                            'GH1', 'GH2', 'GH3', 'GH4', 'GH5', 'GH6', 'GH7', 'GH8'])

        validCompCol3x3 = (['ADG', 'BEH',
                            'CF1', 'CF2', 'CF3', 'CF4', 'CF5', 'CF6', 'CF7', 'CF8'])

        validCompDiag3x3 = (['BFG', 'CDH',
                            'AE1', 'AE2', 'AE3', 'AE4', 'AE5', 'AE6', 'AE7', 'AE8'])

        validCompAll3x3 = validCompRow3x3 + validCompCol3x3 + validCompDiag3x3
        #########################################

        for figureName in problem.figures:

            thisFig = problem.figures[figureName]
            figImage = Image.open(thisFig.visualFilename)
            #figImage.show()
            figures[figureName] = figImage


        if (problem.problemType == '2x2'):
            all_scores2x2 = self.ComputeScore(figures, validCompAll2x2, 'mergeImagePixC')
            listOfConfidence = self.ComputeResults2x2(all_scores2x2, validCompRow2x2, validCompCol2x2, validCompDiag2x2)
            if self.debugL2:
                for x in all_scores2x2.items(): print x
            if self.debugL1 or self.debugL2:
                print '\n', listOfConfidence, '\n'

        elif (problem.problemType == '3x3'):
            listOfConfidenceMI = [0.0]*8
            listOfConfidenceNM = [0.0]*8
            listOfConfidenceNP = [0.0]*8
            listOfConfidence = [0.0]*8

            if (re.search(r'C-[0-9]', problem.name)):

                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'mergeImagePixC')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceMI = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=True)

                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'imgNumPyStats')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceNP = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=True)

            if (re.search(r'D-[0-9]', problem.name)):

                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'mergeImagePixC')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceMI = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=False)

                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'noMergeImgPixC')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceNM = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=False)

                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'imgNumPyStats')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceNP = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=False)

            if (re.search(r'E-[0-9]', problem.name)):
                all_scores3x3 = self.ComputeScore(figures, validCompAll3x3, 'mergeImagePixC')
                if self.debugL2:
                    for k in sorted(all_scores3x3.keys(), key=self.SortDict): print k, all_scores3x3[k]
                listOfConfidenceMI = self.ComputeResults3x3(all_scores3x3, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag=False)

            listOfConfidence = [sum(x) for x in zip(listOfConfidenceMI, listOfConfidenceNM, listOfConfidenceNP)]

            if self.debugL1 or self.debugL2:
                print listOfConfidenceMI
                print listOfConfidenceNM
                print listOfConfidenceNP
                print '\n', listOfConfidence, '\n'

        maxScore = self.FindMaxScore(listOfConfidence)
        normMaxScore = self.NormalizeList(0, maxScore)

        if self.debugL1:
            myAnswer = max(normMaxScore)
            print normMaxScore

        return normMaxScore


    #########################################################
    # agent functions
    #########################################################

    def SortDict(self, string):
        '''
        This function used only for DEBUG
        It will present the debug printout in a nice order
        '''

        if (re.search(r'ABC|DEF|^GH', string)):
            return 'a'+string[1]+string[2]
        elif (re.search(r'ADG|BEH|^CF', string)):
            return 'b'+string[1]+string[2]
        elif (re.search(r'BFG|CDH|^AE', string)):
            if (re.search(r'[0-9]', string)):
                return 'd'+string[1]+string[2]
            else:
                return 'c'+string[2]


    def NormalizeList(self, myNum, myList):
        f = [float(i) for i in myList]
        sumList = sum(f)
        normList = [abs(myNum - (x/sumList)) for x in f]

        return normList


    def FindMaxScore(self, myList):
        '''
        Function will identify choices that have the smallest Euclidean distance
        and return list of elements [1,0]
        '''

        maxScore = min(myList)
        for x in range(len(myList)):
            if myList[x] == maxScore:
                myList[x] = 1.0
            else:
                myList[x] = 0.0

        return myList


    def PixelCount(self, fig):
        '''
        RGB white [255, 255, 255]
        RGB black [0, 0, 0]
        ...
        '''

        pixel_counts = {}

        image = fig.convert("RGB")
        RGB = image.getdata()

        total = 0.0
        black = 0.0
        white = 0.0

        grey01 = 0.0
        grey02 = 0.0
        grey03 = 0.0
        grey04 = 0.0
        grey05 = 0.0

        grey06 = 0.0
        grey07 = 0.0
        grey08 = 0.0
        grey09 = 0.0
        grey10 = 0.0
        
        greys = 0.0

        tmpDict = {}
        currentVal = RGB[0]

        for value in RGB:

            total += 1.0

            #Major spectrum, black, white
            if ( value[:3] == (0, 0, 0) ):
                black += 1.0
            if ( value[:3] == (255, 255, 255) ):
                white += 1.0

            # Major 'Grey' spectrum
            if ( value[:3] == (42, 42, 42) ):
                grey01 += 1.0
            if ( value[:3] == (85, 85, 85) ):
                grey02 += 1.0
            if ( value[:3] == (127, 127, 127) ):
                grey03 += 1.0
            if ( value[:3] == (170, 170, 170) ):
                grey04 += 1.0
            if ( value[:3] == (212, 212, 212) ):
                grey05 += 1.0

            # Minor 'Grey' spectrum
            if ( value[:3] == (69, 69, 69) ):
                grey06 += 1.0
            if ( value[:3] == (111, 111, 111) ):
                grey08 += 1.0
            if ( value[:3] == (154, 154, 154) ):
                grey09 += 1.0
            if ( value[:3] == (196, 196, 196) ):
                grey07 += 1.0
            if ( value[:3] == (239, 239, 239) ):
                grey10 += 1.0

            if ( value[:3] != (0, 0, 0) ) and ( value[:3] != (255, 255, 255) and

                 value[:3] != (42, 42, 42) and value[:3] != (85, 85, 85) and value[:3] != (127, 127, 127) and
                 value[:3] != (170, 170, 170) and value[:3] != (212, 212, 212) and

                 value[:3] != (69, 69, 69) and value[:3] != (111, 111, 111) and value[:3] != (154, 154, 154) and
                 value[:3] != (196, 196, 196) and value[:3] != (239, 239, 239)
                ):
                #print value
                greys += 1.0

            # For debugging --- to count all pixel values
            if value == currentVal:
                if not 'RGB-'+str(currentVal[0]) in tmpDict:
                    tmpDict['RGB-'+str(currentVal[0])] = 1.0
                else:
                    tmpDict['RGB-'+str(currentVal[0])] += 1.0

            else:
                currentVal = value
                if not 'RGB-'+str(currentVal[0]) in tmpDict:
                    tmpDict['RGB-'+str(currentVal[0])] = 1.0
                else:
                    tmpDict['RGB-'+str(currentVal[0])] += 1.0


        #print total, white+black+greys
        pixel_counts['black'] = black
        pixel_counts['white'] = white
        #pixel_counts['greys'] = greys

        pixel_counts['grey01'] = grey01
        pixel_counts['grey02'] = grey02
        pixel_counts['grey03'] = grey03
        pixel_counts['grey04'] = grey04
        pixel_counts['grey05'] = grey05

        pixel_counts['grey06'] = grey06
        pixel_counts['grey07'] = grey07
        pixel_counts['grey08'] = grey08
        pixel_counts['grey09'] = grey09
        pixel_counts['grey10'] = grey10


        if self.debugCP:
            print '========================\n'
            print sorted(tmpDict.iteritems(), reverse=True, key=lambda x: int(x[1]))

        return pixel_counts


    def MergeImage(self, pil_figList):

        average_im = 0.0

        for pil_fig in pil_figList:
            average_im += np.array(pil_fig.convert('F'))
        average_im /= len(pil_figList)
        pil_mergedFigs = Image.fromarray(average_im).convert("RGB")
        #pil_mergedFigs.show()

        return pil_mergedFigs


    def ScoreNumpyStats(self, figList):

        numpyStats = {}

        fig1 = np.asarray(figList[0].getdata().convert('L'))
        fig2 = np.asarray(figList[1].getdata().convert('L'))
        figs = np.asarray(figList.pop().getdata().convert('L'))

        score = np.sum(figs > fig2) + np.sum(figs > fig1)
        DEBUG = "%-5s %-5s-> %-5s" %(np.sum(figs > fig2), np.sum(figs > fig1), score)

        if ( len(figList) == 3 ):
            fig3 = np.asarray(figList[2].getdata().convert('L'))
            score = np.sum(figs > fig3) + np.sum(figs > fig2) + np.sum(figs > fig1)
            DEBUG = "%-5s %-5s %-5s-> %-5s" %(np.sum(figs > fig3), np.sum(figs > fig2), np.sum(figs > fig1), score)

        if self.debugNP:
            print DEBUG

        numpyStats['NumPY'] = score
        return numpyStats


    def ComputeScore(self, figures, validComp, function):

        all_scores = {}

        mergeImagePixC = False
        noMergeImgPixC = False
        imgNumPyStats = False
        figureSymmetry = False
        
        if function == 'mergeImagePixC':
            mergeImagePixC = True
        if function == 'noMergeImgPixC':
            noMergeImgPixC = True
        if function == 'imgNumPyStats':
            imgNumPyStats = True

        is3x3 = False
        if len(validComp[0]) == 3:
            is3x3 = True

        for figs in validComp:

            pil_figList = []
            matchIndex = figs
            if self.debugNP:
                print matchIndex

            fig1 = figures[str(matchIndex[0])]
            fig2 = figures[str(matchIndex[1])]
            pil_figList.append(fig1)
            pil_figList.append(fig2)

            if is3x3:
                fig3 = figures[str(matchIndex[2])]
                pil_figList.append(fig3)


            #########################
            #Functions
            #########################

            if mergeImagePixC:
                all_scores[matchIndex] = self.PixelCount(self.MergeImage(pil_figList))

            if noMergeImgPixC:
                pixelCount = {}
                sum_black = 0

                A = self.PixelCount(fig1)['black']
                B = self.PixelCount(fig2)['black']
                sum_black = abs(A - B)

                if is3x3:
                    C = self.PixelCount(fig3)['black']
                    sum_black = abs(A - B) + abs(A - C) + abs(B - C)

                pixelCount['black'] = sum_black
                all_scores[matchIndex] = pixelCount

                if self.debugCS:
                    print matchIndex, '--------------------'
                    print A
                    print B
                    print C
                    print pixelCount

            if imgNumPyStats:
                mergedFigs = self.MergeImage(pil_figList)
                pil_figList.append(mergedFigs)
                all_scores[matchIndex] = self.ScoreNumpyStats(pil_figList)

                if self.debugCS:
                    print matchIndex, '--------------------\n'
                    print all_scores[matchIndex]

        return all_scores


    def ComputeResults2x2(self, all_scores, validCompRow2x2, validCompCol2x2, validCompDiag2x2):
        '''
        Evaluate choices relative to correlation between transformations, and
        Count the difference between rows: [AB], [C1 - C6] and columns: [AC], [B1 - B6]
        '''

        corspdWeight = 0.975

        listOfConfidence = []
        listOfConfidenceR = []
        listOfConfidenceC = []
        listOfConfidenceD = []

        # Compute for rows, AB: {C1 - C6]:
        LL_key = 'AB'

        for fig2fig in validCompRow2x2:

            sum_conf = 0
            sum_1 = 0
            sum_2 = 0
            if (re.search(r'[0-9]', fig2fig)):
                LN_key = fig2fig

                for key in all_scores[LL_key].keys():
                    sum_conf += abs(all_scores[LL_key][key] - all_scores[LN_key][key])
                    if self.debugL3:
                        print LL_key, LN_key, key
                        print "    %-7s %-7s -> %-7s" %(all_scores[LL_key][key], all_scores[LN_key][key], sum_conf)

                listOfConfidenceR.append(sum_conf)

        # Compute for columns, AC: {B1 - B6]:
        LL_key = 'AC'

        for fig2fig in validCompCol2x2:

            sum_conf = 0
            sum_1 = 0
            sum_2 = 0
            if (re.search(r'[0-9]', fig2fig)):
                LN_key = fig2fig

                for key in all_scores[LL_key].keys():
                    sum_conf += abs(all_scores[LL_key][key] - all_scores[LN_key][key])
                    if self.debugL3:
                        print LL_key, LN_key, key
                        print "    %-7s %-7s -> %-7s" %(all_scores[LL_key][key], all_scores[LN_key][key], sum_conf)

                listOfConfidenceC.append(sum_conf)

        # Compute for Diagonal
        LL_key = 'BC'

        for fig2fig in validCompDiag2x2:

            sum_conf = 0
            sum_1 = 0
            sum_2 = 0
            if (re.search(r'[0-9]', fig2fig)):
                LN_key = fig2fig

                for key in all_scores[LL_key].keys():
                    sum_conf += abs(all_scores[LL_key][key] - all_scores[LN_key][key])
                    if self.debugL3:
                        print LL_key, LN_key, key
                        print "    %-7s %-7s -> %-7s" %(all_scores[LL_key][key], all_scores[LN_key][key], sum_conf)

                listOfConfidenceD.append(sum_conf)

        listOfConfidence = [sum(x) for x in zip(listOfConfidenceC, listOfConfidenceR, listOfConfidenceD)]
        return listOfConfidence


    def ComputeResults3x3(self, all_scores, validCompRow3x3, validCompCol3x3, validCompDiag3x3, solveDiag):
        '''
        Evaluate choices relative to correlation between transformations, and
        Count the difference between rows and columns
        '''

        corspdWeight = 0.90
        maxValue = 100

        listOfConfidence = []
        listOfConfidenceR = []
        listOfConfidenceC = []
        listOfConfidenceD = []

        #Calculate for Rows
        LL_key1 = 'ABC'
        LL_key2 = 'DEF'

        for fig2fig in validCompRow3x3:

            sum_conf = 0
            if (re.search(r'[0-9]', fig2fig)):
                LN_key = fig2fig

                for key in all_scores[LL_key1].keys():

                    sum_T = 0
                    a = all_scores[LL_key1][key]
                    b = all_scores[LL_key2][key]
                    c = all_scores[LN_key][key]

                    sum_T += abs(abs(a - c) + abs(b - c))
                    if ( self.IsClose(a, b, corspdWeight) and (a <= c and b >= c) ):
                        sum_T = 0

                    if self.debugL3:
                        print "%-8s %-7s %-7s    %-7s" %(key, LL_key1, LL_key2, LN_key)
                        print "         %-7s %-7s -> %-7s" %(a, b, c)
                        print "         %-18s %-7s" %('SCORE', sum_T)

                    sum_conf += sum_T
                listOfConfidenceR.append(sum_conf)

                if self.debugL3:
                    print listOfConfidenceR, '\n'

        #Calculate for Columns
        LL_key1 = 'ADG'
        LL_key2 = 'BEH'

        for fig2fig in validCompCol3x3:

            sum_conf = 0
            if (re.search(r'[0-9]', fig2fig)):
                LN_key = fig2fig

                for key in all_scores[LL_key1].keys():

                    sum_T = 0
                    a = all_scores[LL_key1][key]
                    b = all_scores[LL_key2][key]
                    c = all_scores[LN_key][key]

                    sum_T += abs(abs(a - c) + abs(b - c))
                    if ( self.IsClose(a, b, corspdWeight) and (a <= c and b >= c) ):
                        sum_T = 0

                    if self.debugL3:
                        print "%-8s %-7s %-7s    %-7s" %(key, LL_key1, LL_key2, LN_key)
                        print "         %-7s %-7s -> %-7s" %(a, b, c)
                        print "         %-18s %-7s" %('SCORE', sum_T)

                    sum_conf += sum_T
                listOfConfidenceC.append(sum_conf)

                if self.debugL3:
                    print listOfConfidenceC, '\n'

        if solveDiag:
            #Calculate for Diagonal
            LL_key1 = 'BFG'
            LL_key2 = 'CDH'

            for fig2fig in validCompDiag3x3:

                sum_conf = 0
                if (re.search(r'[0-9]', fig2fig)):
                    LN_key = fig2fig

                    for key in all_scores[LL_key1].keys():

                        sum_T = 0
                        a = all_scores[LL_key1][key]
                        b = all_scores[LL_key2][key]
                        c = all_scores[LN_key][key]

                        sum_T += abs(abs(a - c) + abs(b - c))
                        if ( self.IsClose(a, b, corspdWeight) and (a <= c and b >= c) ):
                            sum_T = 0

                        if self.debugL3:
                            print "%-8s %-7s %-7s    %-7s" %(key, LL_key1, LL_key2, LN_key)
                            print "         %-7s %-7s -> %-7s" %(a, b, c)
                            print "         %-18s %-7s" %('SCORE', sum_T)

                        sum_conf += sum_T
                    listOfConfidenceD.append(sum_conf)

        else:
            listOfConfidenceD = [0]*8

        if self.debugL3:
            print listOfConfidenceD, '\n'

        listOfConfidence = [sum(x) for x in zip(listOfConfidenceC, listOfConfidenceR, listOfConfidenceD)]
        return listOfConfidence


    def IsClose(self, val_1, val_2, weight):
        '''
        This function will determine how 'numerically' close two numbers
        are to each other. Based on % closeness, return boolean, True, False
        '''

        if (val_1 and val_2) < 0:
            val_1 = abs(val_1)
            val_2 = abs(val_2)

        if ( ((val_1) >= (val_2) and
              (val_2) >= (val_1 * weight)) or

             ((val_2) >= (val_1) and
              (val_1) >= (val_2 * weight)) ):

            return True

        else:

            return False
