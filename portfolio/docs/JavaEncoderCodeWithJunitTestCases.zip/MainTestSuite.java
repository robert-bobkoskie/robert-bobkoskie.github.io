package edu.gatech.seclass.encode;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({MainTest.class, MyMainTest.class})

public class MainTestSuite {}
