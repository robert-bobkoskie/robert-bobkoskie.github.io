package edu.gatech.seclass.encode;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.Assert.*;

public class MyMainTest {
	
	private ByteArrayOutputStream outStream;
    private ByteArrayOutputStream errStream;
    private PrintStream outOrig;
    private PrintStream errOrig;
    private Charset charset = StandardCharsets.UTF_8;

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Before
    public void setUp() throws Exception {
        outStream = new ByteArrayOutputStream();
        PrintStream out = new PrintStream(outStream);
        errStream = new ByteArrayOutputStream();
        PrintStream err = new PrintStream(errStream);
        outOrig = System.out;
        errOrig = System.err;
        System.setOut(out);
        System.setErr(err);
    }

    @After
    public void tearDown() throws Exception {
        System.setOut(outOrig);
        System.setErr(errOrig);
    }

    // Some utilities

    private File createTmpFile() throws IOException {
        File tmpfile = temporaryFolder.newFile();
        tmpfile.deleteOnExit();
        return tmpfile;
    }

    private File createInputFileInt(int myInt) throws Exception {
        File file =  createTmpFile();
        FileWriter fileWriter = new FileWriter(file);
        fileWriter.write(myInt);
        fileWriter.close();
		
        return file;
    }

    private File createInputFileString(String myString) throws Exception {
        File file =  createTmpFile();
        FileWriter fileWriter = new FileWriter(file);
		fileWriter.write(myString);
		fileWriter.close();
		
		/*
        fileWriter.write("Howdy Billy,\n" +
                "I am going to take cs6300 and cs6400 next semester.\n" +
                "Did you take cs 6300 last semester? I want to\n" +
                "take 2 courses so that I will graduate Asap!");
		*/
		
        return file;
    }
	
    private String getFileContent(String filename) {
        String content = null;
        try {
            content = new String(Files.readAllBytes(Paths.get(filename)), charset);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }

    
	// Test Cases
	
	/* Purpose: If none of the OPT flags is specified, encode will default to
				applying -c <length of file>, a caesar cipher incrementing by
				the number of characters in the input file.
				In this case, there are no OPT flags set and the input files has
				length == 6, therefore, it is expected that all alphabetic chars
				will be incremented by 6.
	
				INPUT:
						File Size    :  >1
						File Content :  alpha chars
						CMD Options  :  <FILE>
						CMD Args     :  <n/a>
	
	Frame #: Test Case 36            (Key = 3.6.4.0.)
	*/
	
	@Test
    public void MyMainTest1() throws Exception {
        File inputFile = createInputFileString("abcxyz");
        String args[] = {inputFile.getPath()};
        Main.main(args);

        String expected = "ghidef";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If none of the OPT flags is specified, encode will default to
				applying -c <length of file>, a caesar cipher incrementing by
				the number of characters in the input file.
				In this case, there are no OPT flags set and the input files has
				length == 6. The file contains only ints, thus, it is expected
				that input file will not be modified.
	
				INPUT:
						File Size    :  >1
						File Content :  ints
						CMD Options  :  <FILE>
						CMD Args     :  <n/a>
	
	Frame #: Test Case 19            (Key = 3.5.4.0.)
	*/
	
	@Test
    public void MyMainTest2() throws Exception {
        File inputFile = createInputFileString("123456789abc");
        String args[] = {inputFile.getPath()};
        Main.main(args);

        String expected = "123456789mno";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If none of the OPT flags is specified, encode will default to
				applying -c <length of file>, a caesar cipher incrementing by
				the number of characters in the input file.
				In this case, there are no OPT flags set and the input files has
				length == 6, therefore, it is expected that all alphabetic chars
				will be incremented by 6. Note the file also contains: special char(s),
				space(s) and int(s). Only alphabetic chars will be shifted.
				
				The file contains only ints, thus, it is
				expected that input file will not be modified.
	
				INPUT:
						File Size    :  >1
						File Content :  ALL chars
						CMD Options  :  <FILE>
						CMD Args     :  <n/a>
	
	Frame #: Test Case 53            (Key = 3.9.4.0.)
	*/
	
	@Test
    public void MyMainTest3() throws Exception {
        File inputFile = createInputFileString("ab ,\n\n\tu3");
        String args[] = {inputFile.getPath()};
        Main.main(args);

        String expected = "jk ,\n\n\td3";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains only alphbetic chars that match the
				chars passed as an argument with the -d flag. Thus, all chars in the
				file qill be deleted, leaving an empty file.
	
				INPUT:
						File Size    :  >1
						File Content :  alpha chars
						CMD Options  :  -r -c -d <FILE>
						CMD Args     :  int chars

	Frame #: Test Case 48            (Key = 3.6.13.8.)
	*/
	
	@Test
    public void MyMainTest4() throws Exception {
        File inputFile = createInputFileString("aabbcc");
        String args[] = {"-r", "-c", "7", "-d", "abc", inputFile.getPath()};
        Main.main(args);

        String expected = "";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains only alphbetic chars that match some
				of the chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will then be
				reversed, then a cipher shift of 7 positions on the alpha chars.
	
				INPUT:
						File Size    :  >1
						File Content :  alpha chars
						CMD Options  :  -r -c -d <FILE>
						CMD Args     :  int chars

	Frame #: Test Case 48            (Key = 3.6.13.8.)
	*/
	
	@Test
    public void MyMainTest5() throws Exception {
        File inputFile = createInputFileString("aabcdee");
        String args[] = {"-r", "-c", "7", "-d", "ae", inputFile.getPath()};
        Main.main(args);

        String expected = "kji";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains all chars that match some of the
				chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will then be
				reversed, then a cipher shift of 7 positions on the alpha chars.
	
				INPUT:
						File Size    :  >1
						File Content :  ALL chars
						CMD Options  :  -r -c -d <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 65            (Key = 3.9.13.8.)
	*/
	
	@Test
    public void MyMainTest6() throws Exception {
        File inputFile = createInputFileString("aabzc0ee \n 1E2");
        String args[] = {"-r", "-c", "-1", "-d", "ae", inputFile.getPath()};
        Main.main(args);

        String expected = "0bya \n 2D1";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains all chars that match some of the
				chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will then be
				reversed, then a cipher shift of 2 positions on the alpha chars.
	
				INPUT:
						File Size    :  >1
						File Content :  ALL chars
						CMD Options  :  -r -c -d <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 65            (Key = 3.9.13.8.)
	*/
	
	@Test
    public void MyMainTest7() throws Exception {
        File inputFile = createInputFileString("abz\\\\n019");
        String args[] = {"-c", "1", "-d", "n", inputFile.getPath()};
        Main.main(args);

        String expected = "bca\\\\019";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains only ints that match none of the
				chars passed as an argument with the -d flag. The ints will be reversed,
				without a cipher shift on the ints.
	
				INPUT:
						File Size    :  >1
						File Content :  ints
						CMD Options  :  -r -c -d <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 31            (Key = 3.5.13.8.)
	*/
	
	@Test
    public void MyMainTest8() throws Exception {
        File inputFile = createInputFileString("123\\\\\\\\n\nabc");
        String args[] = {"-r","-d", "-n", inputFile.getPath()};
        Main.main(args);

        String expected = "\\\\\\\\321\ncba";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains all chars that match some of the
				chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will have a
				cipher shift of 7 positions on the alpha chars, then be reversed.
	
				INPUT:
						File Size    :  >1
						File Content :  alpha chars
						CMD Options  :  -c -r -d <FILE>
						CMD Args     :  int chars

	Frame #: Test Case 50            (Key = 3.6.14.8.)
	*/
	
	@Test
    public void MyMainTest9() throws Exception {
        File inputFile = createInputFileString("aabcdee");
        String args[] = {"-c", "7", "-r", "-d", "ae", inputFile.getPath()};
        Main.main(args);

        String expected = "kji";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains only ints that match none of the
				chars passed as an argument with the -d flag. The ints will be reversed,
				without a cipher shift on the ints.
	
				INPUT:
						File Size    :  >1
						File Content :  ints
						CMD Options  :  -c -r -d <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 33            (Key = 3.5.14.8.)
	*/
	
	@Test
    public void MyMainTest10() throws Exception {
        File inputFile = createInputFileString("abc\tt123\t");
        String args[] = {"-c", "1", "-r", "-d", "jit", inputFile.getPath()};
        Main.main(args);

        String expected = "dcb\t321\t";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: If multiple OPT flags is specified, the "-d" flag is applied first.
				In this case, the file contains all chars that match some of the
				chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will then have
				a cipher shift of 7 positions on the alpha chars, then be reversed.
	
				INPUT:
						File Size    :  >1
						File Content :  ALL chars
						CMD Options  :  -c -r -d <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 67            (Key = 3.9.14.8.)
	*/
	
	@Test
    public void MyMainTest11() throws Exception {
        File inputFile = createInputFileString("aab\nn,9ez\n");
        String args[] = {"-c", "1", "-r", "-d", "aen", inputFile.getPath()};
        Main.main(args);

        String expected = "c\na9,\n";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: Multiple OPT flags is specified. In this case, the "-d" flag is the
				first flag.	The file contains all chars that match some of the
				chars passed as an argument with the -d flag. Thus, only matching
				chars in the file will be deleted. The remaining chars will then be
				reversed, then have	a cipher shift of 7 positions on the alpha chars.
	
				INPUT:
						File Size    :  >1
						File Content :  ALL chars
						CMD Options  :  -d -r -c <FILE>
						CMD Args     :  int chars
	
	Frame #: Test Case 69            (Key = 3.9.15.8.)
	*/
	
	@Test
    public void MyMainTest12() throws Exception {
        File inputFile = createInputFileString("bB2/n,3\\n");
        String args[] = {"-d", "aen", "-r", "-c", "10", inputFile.getPath()};
        Main.main(args);

        String expected = "\\3,/2Ll";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: OPT flags are set, but will not matter, as an empty file is
				passed in. Thus the file will not be modified.
	
				INPUT:
						File Size :  empty
	
	Frame #: Test Case 1             <single>
	*/
	
	@Test
    public void MyMainTest13() throws Exception {
        File inputFile = createInputFileString("");
        String args[] = {"-d", "ae", "-r", "-c", "7", inputFile.getPath()};
        Main.main(args);

        String expected = "";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: OPT flags are set, but will not matter, as an file that
				contains only spaces is	passed in. Thus the file will
				not be modified.
	
				INPUT:
						File Content :  spaces
	
	Frame #: Test Case 2             <single>
	*/
	
	@Test
    public void MyMainTest14() throws Exception {
        File inputFile = createInputFileString(" ");
        String args[] = {"-d", "ae", "-r", "-c", "7", inputFile.getPath()};
        Main.main(args);

        String expected = " ";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	/* Purpose: Incorrect OPT flags are set, thus an error message is expected.
	
				INPUT:
						CMD Args :  -c ints


	Frame #: Test Case 8             <error>
	*/
	
	@Test
    public void MyMainTest15() throws Exception {
        File inputFile = createInputFileString("19/n,\\\naAzZ\n");
        String args[] = {"-r", "-c", "26", inputFile.getPath()};
        Main.main(args);

		String expected = "\\,n/91\nZzAa\n";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest16() throws Exception {
        File inputFile = createInputFileString("AazZbB\n,3\\m");
        String args[] = {"-r", "-c", "1", "-d", "aB", inputFile.getPath()};
        Main.main(args);

        String expected = "cAaB\nn\\3,";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest17() throws Exception {
        File inputFile = createInputFileString("ab\t\t\tcdef");
		String args[] = {"-d", "\t", inputFile.getPath()};
        Main.main(args);
        String expected = "abcdef";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest18() throws Exception {
        File inputFile = createInputFileString("123\n456 789\tabc");
		String args[] = {"-r", inputFile.getPath()}; //invalid argument
        Main.main(args);
        String expected = "321\n654 987\tcba";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest19() throws Exception {
        File inputFile = createInputFileString("091\n\\oaAzZbB");
		String args[] = {"-c", "-1", inputFile.getPath()};
        Main.main(args);
        String expected = "091\n\\nzZyYaA";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest20() throws Exception {
        File inputFile = createInputFileString("a\nd");
		String args[] = {"-c", "1", inputFile.getPath()};
        Main.main(args);
        String expected = "b\ne";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest21() throws Exception {
        File inputFile = createInputFileString("a\ndef");
		String args[] = {"-r", inputFile.getPath()};
        Main.main(args);
        String expected = "a\nfed";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("The files differ!", expected, actual);
    }
	
	@Test
    public void MyMainTest22() throws Exception {
        File inputFile = createInputFileString("123\ndef");
		String args[] = {"-R", inputFile.getPath()};
        Main.main(args);
        String expected = "def\n123";
        String actual = getFileContent(inputFile.getPath());
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest23() throws Exception {
        String args[] = {"-r", "e"}; //invalid argument
        Main.main(args);
        assertEquals("File Not Found", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest24() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r", "-de", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest25() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r1", "-d", "e", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest26() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r", "-c1", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest27() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r", "-c", "e", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest28() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r", "-c", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest29() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r", "-d", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
	
	@Test
    public void MyMainTest30() throws Exception {
		File inputFile = createInputFileString("abc");
        String args[] = {"-r-r", inputFile.getPath()}; //invalid argument
        Main.main(args);
        assertEquals("Usage: Encode  [-c int] [-d string] [-r] <filename>", errStream.toString().trim());
    }
}
