package edu.gatech.seclass.encode;

/*
 * Run tests from command line as follows:
 * C:\GTECH_GITHUB\GTECH_CS6300-SDP\ASSIGNMENTS\6300Summer18rbobkoskie3\IndividualProject\src\edu\gatech\seclass>java -cp ..\..\.. edu.gatech.seclass.Encode werewr
 */

import java.lang.*;
import java.io.*;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Hashtable;
import java.util.regex.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.ListIterator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileInputStream;



import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;


public class Main {
	private static Charset char_set = StandardCharsets.UTF_8;
	
	private int cipherVal = 0;
	private String charsToDelete = "";
	private static boolean ENCODE = true;
	
	private ByteArrayOutputStream outStream;
	private ByteArrayOutputStream errStream;
	private PrintStream outOrig;
	private PrintStream errOrig;
	
	
	public static void main(String[] args) {
		Main myEncode = new Main();
		
		if (args == null) {
			myEncode.usage();
			return;
			// System.exit(0);
			// throw new Exception("NullPointerException");
		}
		
		if (args.length == 0) {
			myEncode.usage();
			return;
			// System.exit(0);
			// throw new Exception("NullPointerException");
		}
		
		// String FILE = "";
		// String FILE = 	"ab   c\nd\tef\n123";
		// String FILE = 	"aAbBc       0189 111\t222 333 444 xXyYzZ";
		/*
		String FILE =	"Howdy Billy,\n" +
						"I am going to take cs6300 and cs6400 next semester.\n" +
						"Did you take cs 6300 last semester? I want to\n" +
						"take 2 courses so that I will graduate Asap!";
		///*
		String FILE =	"Let's try some **special**  %!(characters)!% ###\n" +
						"and line breaks^$@ \r" +
						"of \\different// types; \n" +
						"in 1 file\r"+
						":-)";
		
		String FILE =	"Howdy Billy," + System.lineSeparator() +
						"I am going to take cs6300 and cs6400 next semester."  + System.lineSeparator() +
						"Did you take cs 6300 last semester? I want to"  + System.lineSeparator() +
						"take 2 courses so that I will graduate Asap!";
		*/
		
		File fileToEncode = new File(args[args.length-1]);
		ENCODE = true;
		// FOR TESTING:
		// try {myEncode.writeFile(fileToEncode, FILE);
		// } catch (Exception e) {}
		
		List<String> CMD_ARGS = new ArrayList<>();
		Collections.addAll(CMD_ARGS, args);
		System.out.println("ARGS: "+CMD_ARGS);
		CMD_ARGS.remove(CMD_ARGS.size() - 1); // Remove File name from args
		System.out.println("ARGS: "+CMD_ARGS);
		
		if (args.length == 1) {
			try (FileInputStream fis = new FileInputStream(fileToEncode.getAbsoluteFile())) {
				// System.out.println("Total file size to read (in bytes) : "+ fis.available());
				myEncode.cipherVal = fis.available();
				/*
				int content;
				while ((content = fis.read()) != -1) {
					// System.out.print((char) content);
				}
				*/
				// System.out.println("-c "+myEncode.cipherVal);
				String[] ARGS = new String[2];
				ARGS[0] = "-c";
				ARGS[1] = Integer.toString(myEncode.cipherVal);
				// myEncode.encodeFile(encoded_file, ARGS);
				myEncode.encodeFile(fileToEncode, ARGS);
			} catch (Exception e) {
				// e.printStackTrace();
				// myEncode.usage();
				// throw new Exception("File Not Found");
				// System.exit(1);
				System.err.println("File Not Found");
				return;
			}
		}
		
		else if (args.length > 1) {			
			
			// for (int counter = 0; counter < CMD_ARGS.size(); counter++) {
			while (!CMD_ARGS.isEmpty()) {
				// System.out.println("ENCODE: "+ENCODE);
				if (!ENCODE) {
					CMD_ARGS.clear();
					return;
				}
				
				if (CMD_ARGS.contains("-d")) {
					String CMD = "-d";
					int INDEX = CMD_ARGS.indexOf(CMD);
					
					try {
						myEncode.charsToDelete = CMD_ARGS.get(INDEX+1);
						String[] ARGS = new String[2];
						ARGS[0] = CMD;
						ARGS[1] = myEncode.charsToDelete;
						System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
						// myEncode.encodeFile(encoded_file, ARGS);
						myEncode.encodeFile(fileToEncode, ARGS);
						CMD_ARGS.remove(INDEX); // Removes CMD
						CMD_ARGS.remove(INDEX); // Removes ARG, '<String>', because of prev delete, uses INDEX, not INDEX+1
					}
					catch (IndexOutOfBoundsException e) {
						myEncode.usage();
						CMD_ARGS.clear();
						return;
						// System.exit(1);
					}
				}
				
				else {
					if (CMD_ARGS.isEmpty()) {
						myEncode.usage();
						break;
					}
					else if (!CMD_ARGS.contains("-d") &&
							 !CMD_ARGS.contains("-r") &&
							 // !CMD_ARGS.contains("-R") &&
							 !CMD_ARGS.contains("-c")) {
					
							myEncode.usage();
							CMD_ARGS.clear();
							return;
							// System.exit(0);
					}
					
					for (int i = 0; i < CMD_ARGS.size(); i++) {
						
						try	{
							if (CMD_ARGS.get(i).contains("-c")) {
								String CMD = "-c";
								int INDEX = CMD_ARGS.indexOf(CMD);
								
								try	{
									myEncode.cipherVal = Integer.parseInt(CMD_ARGS.get(INDEX+1));
									/*
									if (myEncode.cipherVal < 0) {
										myEncode.cipherVal *= -1;
										System.out.println("Positive INT Please, cipher value will be: "+
															Integer.toString(myEncode.cipherVal));
									}
									*/
									String[] ARGS = new String[2];
									ARGS[0] = CMD;
									ARGS[1] = Integer.toString(myEncode.cipherVal);
									System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
									// myEncode.encodeFile(encoded_file, ARGS);
									myEncode.encodeFile(fileToEncode, ARGS);
									CMD_ARGS.remove(INDEX); // Removes CMD
									CMD_ARGS.remove(INDEX); // Removes ARG, '<String>', because of prev delete, uses INDEX, not INDEX+1
								}
								catch (IndexOutOfBoundsException e) {
									CMD_ARGS.remove(INDEX); // Removes CMD
									myEncode.usage();
									CMD_ARGS.clear();
									return;
									// System.exit(1);
								}
								catch (NumberFormatException e) {
									CMD_ARGS.remove(INDEX); // Removes CMD
									myEncode.usage();
									CMD_ARGS.clear();
									return;
									// System.exit(1);
								}
							}
						}
						catch (IndexOutOfBoundsException e) {
							myEncode.usage();
							CMD_ARGS.clear();
							return;
							// System.exit(1);
						}
						
						try	{
							if (CMD_ARGS.get(i).contains("-r")) {
								String CMD = "-r";
								int INDEX = CMD_ARGS.indexOf(CMD);
								
								try	{
									String NXT_CMD = CMD_ARGS.get(INDEX+1);
									if (NXT_CMD.contains("-r") ||
										// NXT_CMD.contains("-R") ||
										NXT_CMD.contains("-c") ||
										NXT_CMD.contains("-d")) {
										
										String[] ARGS = new String[1];
										ARGS[0] = CMD;
										System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
										// myEncode.encodeFile(encoded_file, ARGS);
										myEncode.encodeFile(fileToEncode, ARGS);
										CMD_ARGS.remove(INDEX); // Removes CMD
									}
									else {
										myEncode.usage();
										CMD_ARGS.clear();
										return;
										// System.exit(0);
									}
								} catch (IndexOutOfBoundsException e) {
									String[] ARGS = new String[1];
									ARGS[0] = CMD;
									System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
									// myEncode.encodeFile(encoded_file, ARGS);
									myEncode.encodeFile(fileToEncode, ARGS);
									CMD_ARGS.remove(INDEX); // Removes CMD
								}
							}
							
							/*
							if (CMD_ARGS.get(i).contains("-R")) {
								String CMD = "-R";
								int INDEX = CMD_ARGS.indexOf(CMD);
								
								try	{
									String NXT_CMD = CMD_ARGS.get(INDEX+1);
									if (NXT_CMD.contains("-r") ||
										NXT_CMD.contains("-R") ||
										NXT_CMD.contains("-c") ||
										NXT_CMD.contains("-d")) {
										
										String[] ARGS = new String[1];
										ARGS[0] = CMD;
										System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
										// myEncode.encodeFile(encoded_file, ARGS);
										myEncode.encodeFile(fileToEncode, ARGS);
										CMD_ARGS.remove(INDEX); // Removes CMD
									}
									else {
										myEncode.usage();
										CMD_ARGS.clear();
										return;
										// System.exit(0);
									}
								} catch (IndexOutOfBoundsException e) {
									String[] ARGS = new String[1];
									ARGS[0] = CMD;
									System.out.println("ARGS "+CMD+" : "+CMD_ARGS);
									// myEncode.encodeFile(encoded_file, ARGS);
									myEncode.encodeFile(fileToEncode, ARGS);
									CMD_ARGS.remove(INDEX); // Removes CMD
								}
							}
							*/
							
						} catch (IndexOutOfBoundsException e) {
							CMD_ARGS.clear();
							return;}
					}
				}
			}
		}
		
		// myEncode.copyFile(encoded_file, "TEST_COPY", false);
	}
	
	private char applyCipher(String STR_CHAR, int cipher) {
		// System.out.println(STR_CHAR+" "+cipher);
		// Hashtable<String, Integer> cipherTable = new Hashtable<String, Integer>();
		// cipherTable.put("a", 1);
		// System.out.println( (int)('a') ); // 97
		// System.out.println((int)('b')); // 98
		// System.out.println((char)(97)); // a
		// System.out.println((char)(98)); // b
		
		
		/* Use ASCII values for A-Z, a-z:
		 * 65  A         97  a
		 * 90  Z        122  z
		 * 48  0
		 * 57  9
		 */
		 
		 int OFFSET = 1;
		 //if (cipher >= 0)
			// OFFSET = 1;
		 //else
			//OFFSET = 2;
		
		char c1 = STR_CHAR.charAt(0);
		int int_chr = (int)c1;
		if (int_chr >= 65 &&  int_chr <= 90) {
			int_chr += cipher;
			if (int_chr < 65)
				int_chr = int_chr +OFFSET - 65 + 90;
			if (int_chr > 90)
				int_chr = int_chr -OFFSET - 90 + 65;
		}
		else if (int_chr >= 97 &&  int_chr <= 122) {
			int_chr += cipher;
			if (int_chr < 97)
				int_chr = int_chr +OFFSET - 97 + 122;
			if (int_chr > 122)
				int_chr = int_chr -OFFSET - 122 + 97;
		}
		else if (int_chr >= 48 &&  int_chr <= 57) {
			int_chr += cipher;
			if (int_chr < 48)
				int_chr = int_chr +OFFSET - 48 + 57;
			if (int_chr > 57)
				int_chr = int_chr -OFFSET - 57 + 48;
		}
		
		char c2 = (char)int_chr;
		// System.out.println(cipher+": "+c1+"  "+c2);
		// String s = Character.toString(c2);

		return c2;
	}
	
	private void encodeFile(File encoded_file, String[] ARGS) {
		// Pattern aA = Pattern.compile("[a-z]", Pattern.CASE_INSENSITIVE);
		// Pattern escape = Pattern.compile("\\\\");
		// Pattern backN = Pattern.compile("\n");
		// Pattern DELETE = Pattern.compile("\\\\[bfnrt]");
		// Pattern W_CHARS = Pattern.compile("\\w+", Pattern.UNICODE_CHARACTER_CLASS);
		Pattern letter = Pattern.compile("[a-zA-Z]");
		Pattern number = Pattern.compile("[0-9]");
		Pattern LET = Pattern.compile("[A-Z]");
		Pattern let = Pattern.compile("[a-z]");
		
		List<String> words = new ArrayList<>();
		ListIterator<String> reverseWords = null;
					
		StringBuilder newLine = new StringBuilder();
		StringBuilder word = new StringBuilder();
		String reverse = "";
		
		InputStreamReader FILE = null;
		try {
			FileInputStream fis = new FileInputStream(encoded_file.getAbsoluteFile());
			FILE = new InputStreamReader(fis, char_set);
			int TEXT_IN = FILE.read();
			while(TEXT_IN != -1) {
				char CHR_CHAR = (char)TEXT_IN;
				// String STR_CHAR = Integer.toString(TEXT_IN);
				String STR_CHAR = Character.toString(CHR_CHAR);
				
				if (ARGS[0].equals("-d")) {
					String charsToDelete = ARGS[1];
					// System.out.println("DELETE THESE CHARS: "+charsToDelete);
					
					for (int i = 0; i < charsToDelete.length(); i++) {
						String c = Character.toString(charsToDelete.charAt(i));
						// System.out.println(c+" "+STR_CHAR);
						// Matcher L = LET.matcher(c);
						// Matcher l = let.matcher(c);
						if (STR_CHAR.equals(c))
							STR_CHAR = STR_CHAR.replace(STR_CHAR, "");
						
						/*
						if (L.matches()) {
							c = c.toLowerCase();
							if (STR_CHAR.equals(c))
								STR_CHAR = STR_CHAR.replace(STR_CHAR, "");
						}
						
						if (l.matches()) {
							c = c.toUpperCase();
							if (STR_CHAR.equals(c))
								STR_CHAR = STR_CHAR.replace(STR_CHAR, "");
						}
						*/
					}
					newLine.append(STR_CHAR);
				}
				
				else if (ARGS[0].equals("-c")) {
					int cipher = Integer.parseInt(ARGS[1]);
					// System.out.println("CIPHER: "+cipher);
					
					Matcher l = letter.matcher(STR_CHAR);
					Matcher n = number.matcher(STR_CHAR);
					if (l.matches()) {
						cipher %= 26;
						STR_CHAR = STR_CHAR.replace(STR_CHAR, Character.toString(applyCipher(STR_CHAR, cipher)));
					}
					/*
					if (n.matches()) {
						cipher %= 10;
						STR_CHAR = STR_CHAR.replace(STR_CHAR, Character.toString(applyCipher(STR_CHAR, cipher)));
					}
					*/
					newLine.append(STR_CHAR);
				}
				
				else if (ARGS[0].equals("-r")) {
					if (!Character.isWhitespace(CHR_CHAR)) {
						word.append(CHR_CHAR);
					}
					else {
						reverse = word.reverse().toString();
						newLine.append(reverse);
						newLine.append(CHR_CHAR);
						word.setLength(0);
					}
				}
				
				else if (ARGS[0].equals("-R")) {
					// System.out.println("--- CHAR: "+CHR_CHAR);
					if (!Character.isWhitespace(CHR_CHAR)) {
						word.append(CHR_CHAR);
					}
					else {
						words.add(word.toString());
						words.add(STR_CHAR);
						// System.out.println("----- WORD: "+word.toString());
						word.setLength(0);
					}
				}
				
				TEXT_IN = FILE.read();
			}
			
			if (ARGS[0].equals("-r")) {
				reverse = word.reverse().toString();
				newLine.append(reverse);
				word.setLength(0);
			}
			else if (ARGS[0].equals("-R")) {
				words.add(word.toString());
				reverseWords = words.listIterator(words.size());
				while(reverseWords.hasPrevious()) {
					newLine.append(reverseWords.previous());
				}
				word.setLength(0);
			}
		}
		catch (Exception e) {
			// e.printStackTrace();
			// throw new Exception("File Not Found");
			System.err.println("File Not Found");
			ENCODE = false;
			return;
		}
		finally {
			try	{
				if (FILE != null)
					FILE.close();
			}
			catch (IOException e) {}
		}
		
		System.out.println("------- LINE: "+newLine.toString());
		try {writeFile(encoded_file.getAbsoluteFile(), newLine.toString());
		} catch (Exception e) {}
		newLine.setLength(0);
	}
	
	private File writeFile(File file, String Text) throws Exception {
		String test_fw = "Ho\twdy Billy,\n" +
						 "I am going to take cs6300 and cs6400 next semester.\n" +
					  	 "Did you take cs 6300 last semester? I want to\n" +
						 "take 2 courses so that I will graduate Asap!";
		
		FileOutputStream fop = new FileOutputStream(file);
		// byte[] contentInBytes = test_fw.getBytes();
		byte[] contentInBytes = Text.getBytes(char_set);
		fop.write(contentInBytes);
		fop.flush();
		fop.close();
		
		return file;
	}
	
	private void copyFile(File sourceFile, String destFile, boolean DELETE) {

		File dest = new File(destFile);
		FileChannel inputChannel = null;
		FileChannel outputChannel = null;
		
		try {
			inputChannel = new FileInputStream(sourceFile).getChannel();
			outputChannel = new FileOutputStream(dest).getChannel();
			outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
		}
		catch (IOException e) {
			System.out.println("FILE: "+sourceFile+" Not Found");
			System.exit(1);
		}
		finally {
			try {
				inputChannel.close();
				outputChannel.close();
			}
			catch (Exception e) {}
		}
		if (DELETE)
			sourceFile.delete();
	}
	
	private static void usage() {
		System.err.println("Usage: Encode  [-c int] [-d string] [-r] <filename>");
	}
}